#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用 JSON/JSONL 条件筛选工具。

示例：
  python3 filter_samples.py samples.json filtered.json \
    --where 'type == "输入侧"' \
    --where 'is_mt == 0'

  python3 filter_samples.py samples.json filtered.json \
    --where 'messages.*.content.*.type == "image_id"' \
    --where 'id in [1, 2, 3]'

多个 --where 默认使用 AND；通过 --logic any 改为 OR。
输出默认是 JSON 数组，适合继续作为原始样例文件使用。
"""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Callable

from risk_json_utils import read_json_or_jsonl, write_json, write_jsonl


BINARY_OPERATORS = (
    "not_contains",
    "not_regex",
    "not_in",
    "contains",
    "regex",
    ">=",
    "<=",
    "!=",
    "==",
    ">",
    "<",
    "in",
)

UNARY_OPERATORS = (
    "not_exists",
    "exists",
    "not_empty",
    "is_empty",
)

NEGATIVE_MULTI_VALUE_OPERATORS = {
    "!=", "not_in", "not_contains", "not_regex",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="按通用条件筛选 JSON/JSONL 样例，输出符合条件的样例文件。",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog="""
条件格式：
  字段路径 运算符 值

支持的运算符：
  ==  !=  >  >=  <  <=
  in  not_in
  contains  not_contains
  regex  not_regex
  exists  not_exists
  is_empty  not_empty

字段路径：
  meta.id
  messages.0.role
  messages.*.role
  messages.*.content.*.type

值优先按 JSON 解析：
  0
  true
  null
  "输入侧"
  [1, 2, 3]

示例：
  --where 'result == 1'
  --where 'type == "输入侧"'
  --where 'id in [1, 5, 9]'
  --where 'text contains "风险"'
  --where 'text regex "(炸弹|爆炸物)"'
  --where 'messages.*.content.*.type == "image_id"'
  --where 'image_id exists'
""",
    )
    parser.add_argument("input", help="待筛选 JSON/JSONL 文件")
    parser.add_argument("output", help="筛选后的输出文件")
    parser.add_argument(
        "--where",
        action="append",
        default=[],
        help="筛选条件，可重复使用；默认多个条件同时满足",
    )
    parser.add_argument(
        "--logic",
        choices=("all", "any"),
        default="all",
        help="多个条件使用 all(AND) 或 any(OR)，默认 all",
    )
    parser.add_argument(
        "--invert",
        action="store_true",
        help="反选：输出不符合整体条件的样例",
    )
    parser.add_argument(
        "--rejected-output",
        help="可选：把未进入主输出的样例另存为 JSON/JSONL",
    )
    parser.add_argument(
        "--output-format",
        choices=("json", "jsonl"),
        default="json",
        help="主输出格式，默认 json",
    )
    parser.add_argument(
        "--rejected-format",
        choices=("json", "jsonl"),
        default="json",
        help="未通过样例输出格式，默认 json",
    )
    return parser.parse_args()


def resolve_values(obj: Any, path: str) -> list[Any]:
    """
    解析点路径，支持：
      dict key
      list index
      * 通配 dict 所有值或 list 所有元素
    """
    parts = path.split(".") if path else []

    def walk(current: Any, index: int) -> list[Any]:
        if index >= len(parts):
            return [current]

        part = parts[index]

        if part == "*":
            if isinstance(current, dict):
                values = list(current.values())
            elif isinstance(current, list):
                values = current
            else:
                return []

            result: list[Any] = []
            for value in values:
                result.extend(walk(value, index + 1))
            return result

        if isinstance(current, dict):
            if part not in current:
                return []
            return walk(current[part], index + 1)

        if isinstance(current, list) and part.isdigit():
            list_index = int(part)
            if 0 <= list_index < len(current):
                return walk(current[list_index], index + 1)
            return []

        return []

    return walk(obj, 0)


def parse_value(text: str) -> Any:
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # 允许不加引号的普通字符串。
        if (
            len(text) >= 2
            and text[0] == text[-1]
            and text[0] in {"'", '"'}
        ):
            return text[1:-1]
        return text


def parse_condition(expression: str) -> tuple[str, str, Any]:
    expression = expression.strip()
    if not expression:
        raise ValueError("筛选条件不能为空")

    # 一元运算符：field exists
    unary_pattern = "|".join(
        sorted(map(re.escape, UNARY_OPERATORS), key=len, reverse=True)
    )
    match = re.fullmatch(
        rf"(?P<field>\S+)\s+(?P<op>{unary_pattern})",
        expression,
    )
    if match:
        return match.group("field"), match.group("op"), None

    # 二元运算符。
    word_ops = [
        op for op in BINARY_OPERATORS
        if op.replace("_", "").isalpha()
    ]
    symbol_ops = [
        op for op in BINARY_OPERATORS
        if op not in word_ops
    ]
    operator_pattern = "|".join(
        [re.escape(op) for op in sorted(word_ops, key=len, reverse=True)]
        + [re.escape(op) for op in sorted(symbol_ops, key=len, reverse=True)]
    )

    match = re.fullmatch(
        rf"(?P<field>\S+)\s+(?P<op>{operator_pattern})\s+(?P<value>.+)",
        expression,
    )
    if not match:
        raise ValueError(
            f"无法解析条件：{expression!r}。"
            "格式应为：字段路径 运算符 值"
        )

    return (
        match.group("field"),
        match.group("op"),
        parse_value(match.group("value")),
    )


def is_empty(value: Any) -> bool:
    return value is None or value == "" or value == [] or value == {}


def safe_compare(left: Any, right: Any, operator: str) -> bool:
    if operator == "==":
        return left == right
    if operator == "!=":
        return left != right

    if operator in {">", ">=", "<", "<="}:
        try:
            if operator == ">":
                return left > right
            if operator == ">=":
                return left >= right
            if operator == "<":
                return left < right
            return left <= right
        except TypeError:
            # 常见数字字符串与数字混用时尝试数值比较。
            try:
                left_number = float(left)
                right_number = float(right)
            except (TypeError, ValueError):
                return False
            if operator == ">":
                return left_number > right_number
            if operator == ">=":
                return left_number >= right_number
            if operator == "<":
                return left_number < right_number
            return left_number <= right_number

    if operator in {"in", "not_in"}:
        try:
            result = left in right
        except TypeError:
            result = False
        return not result if operator == "not_in" else result

    if operator in {"contains", "not_contains"}:
        try:
            if isinstance(left, str):
                result = str(right) in left
            elif isinstance(left, dict):
                result = right in left or right in left.values()
            else:
                result = right in left
        except TypeError:
            result = False
        return not result if operator == "not_contains" else result

    if operator in {"regex", "not_regex"}:
        try:
            result = re.search(str(right), str(left)) is not None
        except re.error as exc:
            raise ValueError(f"非法正则表达式 {right!r}：{exc}") from exc
        return not result if operator == "not_regex" else result

    raise ValueError(f"不支持的运算符：{operator}")


def compile_condition(expression: str) -> Callable[[Any], bool]:
    field, operator, expected = parse_condition(expression)

    def evaluate(record: Any) -> bool:
        values = resolve_values(record, field)

        if operator == "exists":
            return bool(values)
        if operator == "not_exists":
            return not values
        if operator == "is_empty":
            return bool(values) and all(is_empty(value) for value in values)
        if operator == "not_empty":
            return bool(values) and any(not is_empty(value) for value in values)

        if not values:
            return False

        checks = [
            safe_compare(value, expected, operator)
            for value in values
        ]

        # 对 !=、not_in 等否定条件，要求所有匹配值都满足否定；
        # 其余条件只要任一值满足即可，适合通配路径。
        if operator in NEGATIVE_MULTI_VALUE_OPERATORS:
            return all(checks)
        return any(checks)

    return evaluate


def write_records(path: str, records: list[Any], fmt: str) -> None:
    if fmt == "jsonl":
        write_jsonl(path, records)
    else:
        write_json(path, records)


def main() -> None:
    args = parse_args()
    records = read_json_or_jsonl(args.input)

    if not args.where:
        raise SystemExit(
            "至少需要一个 --where 条件。"
            "如需复制全部样例，请直接复制原文件。"
        )

    try:
        conditions = [compile_condition(item) for item in args.where]
    except ValueError as exc:
        raise SystemExit(f"条件错误：{exc}") from exc

    selected: list[Any] = []
    rejected: list[Any] = []

    for record in records:
        results = [condition(record) for condition in conditions]
        matched = all(results) if args.logic == "all" else any(results)
        if args.invert:
            matched = not matched

        if matched:
            selected.append(record)
        else:
            rejected.append(record)

    write_records(args.output, selected, args.output_format)

    if args.rejected_output:
        write_records(
            args.rejected_output,
            rejected,
            args.rejected_format,
        )

    print(f"输入样例数：{len(records)}")
    print(f"符合条件：{len(selected)}")
    print(f"不符合条件：{len(rejected)}")
    print(f"输出文件：{args.output}")
    if args.rejected_output:
        print(f"未通过样例：{args.rejected_output}")


if __name__ == "__main__":
    main()
