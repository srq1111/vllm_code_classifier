#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
按照相同 ID，用第二个 JSON/JSONL 文件中的判定结果，
替换第一个 JSON/JSONL 文件中的判定结果。

位置参数：
  1. target       待替换文件
  2. replacement  替换来源文件

默认原地覆盖 target，并自动创建 target.bak 备份。
"""

from __future__ import annotations

import argparse
import copy
import shutil
from pathlib import Path
from typing import Any

from risk_json_utils import (
    COMMON_ID_KEYS,
    COMMON_RESULT_KEYS,
    auto_get,
    get_by_path,
    normalize_id,
    read_json_or_jsonl,
    set_by_path,
    write_jsonl,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="按相同 ID 替换 JSONL 文件中的判定结果。"
    )
    parser.add_argument("target", help="待替换文件")
    parser.add_argument("replacement", help="替换来源文件")
    parser.add_argument(
        "-o",
        "--output",
        help="输出文件；省略时原地覆盖 target",
    )
    parser.add_argument(
        "--target-id-key",
        help="target 的 ID 字段，支持 meta.id",
    )
    parser.add_argument(
        "--replacement-id-key",
        help="replacement 的 ID 字段，支持 meta.id",
    )
    parser.add_argument(
        "--target-result-key",
        help="target 的判定字段，支持 meta.label",
    )
    parser.add_argument(
        "--replacement-result-key",
        help="replacement 的判定字段，支持 meta.label",
    )
    parser.add_argument(
        "--append-new",
        action="store_true",
        help="把 replacement 中 target 不存在的新 ID 追加到末尾",
    )
    parser.add_argument(
        "--no-backup",
        action="store_true",
        help="原地覆盖时不创建 .bak 备份",
    )
    return parser.parse_args()


def detect_result_key(
    rows: list[Any],
    explicit_key: str | None,
    file_name: str,
) -> str:
    if explicit_key:
        return explicit_key

    for row in rows:
        try:
            _, used_key = auto_get(
                row,
                None,
                COMMON_RESULT_KEYS,
                f"{file_name} 判定结果",
            )
            return used_key
        except (KeyError, ValueError):
            continue

    raise ValueError(
        f"无法自动识别 {file_name} 的判定字段，"
        "请显式指定对应的 --*-result-key。"
    )


def main() -> None:
    args = parse_args()

    target_rows = read_json_or_jsonl(args.target)
    replacement_rows = read_json_or_jsonl(args.replacement)

    if not target_rows:
        raise SystemExit("待替换文件为空。")
    if not replacement_rows:
        raise SystemExit("替换来源文件为空。")

    target_result_key = detect_result_key(
        target_rows,
        args.target_result_key,
        "target",
    )
    replacement_result_key = detect_result_key(
        replacement_rows,
        args.replacement_result_key,
        "replacement",
    )

    replacement_map: dict[str, tuple[Any, Any]] = {}
    replacement_order: list[str] = []
    duplicate_ids: set[str] = set()

    for row_no, row in enumerate(replacement_rows, start=1):
        try:
            raw_id, _ = auto_get(
                row,
                args.replacement_id_key,
                COMMON_ID_KEYS,
                "replacement ID",
            )
            result = get_by_path(row, replacement_result_key)
        except (KeyError, ValueError) as exc:
            raise ValueError(
                f"{args.replacement}: 第 {row_no} 条记录读取失败：{exc}"
            ) from exc

        normalized_id = normalize_id(raw_id)
        if normalized_id in replacement_map:
            duplicate_ids.add(normalized_id)
        else:
            replacement_order.append(normalized_id)

        replacement_map[normalized_id] = (raw_id, result)

    output_rows: list[Any] = []
    target_ids: set[str] = set()
    replaced_count = 0

    for row_no, row in enumerate(target_rows, start=1):
        try:
            raw_id, _ = auto_get(
                row,
                args.target_id_key,
                COMMON_ID_KEYS,
                "target ID",
            )
        except (KeyError, ValueError) as exc:
            raise ValueError(
                f"{args.target}: 第 {row_no} 条记录读取失败：{exc}"
            ) from exc

        normalized_id = normalize_id(raw_id)
        target_ids.add(normalized_id)

        if normalized_id not in replacement_map:
            output_rows.append(row)
            continue

        if not isinstance(row, dict):
            raise ValueError(
                f"{args.target}: 第 {row_no} 条记录不是 JSON 对象。"
            )

        new_row = copy.deepcopy(row)
        set_by_path(
            new_row,
            target_result_key,
            replacement_map[normalized_id][1],
        )
        output_rows.append(new_row)
        replaced_count += 1

    appended_count = 0
    if args.append_new:
        latest_replacement_row: dict[str, Any] = {}

        for row in replacement_rows:
            raw_id, _ = auto_get(
                row,
                args.replacement_id_key,
                COMMON_ID_KEYS,
                "replacement ID",
            )
            latest_replacement_row[normalize_id(raw_id)] = row

        for normalized_id in replacement_order:
            if normalized_id not in target_ids:
                output_rows.append(
                    latest_replacement_row[normalized_id]
                )
                appended_count += 1

    target_path = Path(args.target)
    output_path = Path(args.output) if args.output else target_path

    if (
        output_path.resolve() == target_path.resolve()
        and not args.no_backup
    ):
        backup_path = target_path.with_suffix(
            target_path.suffix + ".bak"
        )
        shutil.copy2(target_path, backup_path)
        print(f"备份文件：{backup_path}")

    write_jsonl(output_path, output_rows)

    print(f"target 记录数：{len(target_rows)}")
    print(f"replacement 记录数：{len(replacement_rows)}")
    print(f"成功替换：{replaced_count}")
    print(f"新增追加：{appended_count}")
    print(f"输出文件：{output_path}")

    if duplicate_ids:
        print(
            f"[提示] replacement 中有 {len(duplicate_ids)} 个重复 ID，"
            "采用每个 ID 的最后一条结果。"
        )


if __name__ == "__main__":
    main()
