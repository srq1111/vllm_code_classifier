# 风险样例 JSON/JSONL 快速处理工具

包含 3 个主要脚本：

- `compare_and_extract.py`
  - 比较 N 个结果文件；
  - 输出全部文件判定一致的 `id + result`；
  - 输出不一致/缺失 ID 的详情；
  - 从原始 JSON/JSONL 中提取对应样例。
- `manual_label.py`
  - 在纯终端中逐条查看样例；
  - 方向键切换；
  - 按 `0/1` 标注；
  - 调用 `chafa` 显示本地图片；
  - 每次标注立即写入 JSONL，支持断点续标。
- `replace_results.py`
  - 按相同 ID，用第二个文件的判定结果替换第一个文件。

公共模块：`risk_json_utils.py`

## 环境

Python 3.9+，人工标注脚本运行于 Linux/macOS 交互式终端。

安装 `chafa`：

```bash
# openEuler / Fedora / RHEL
sudo dnf install chafa

# Ubuntu / Debian
sudo apt install chafa
```

赋予执行权限：

```bash
chmod +x compare_and_extract.py manual_label.py replace_results.py
```

---

## 1. 比较 N 个结果文件并提取分歧样例

假设：

- 原始样例：`samples.json`
- 判定结果：`model_a.jsonl model_b.jsonl model_c.jsonl`

运行：

```bash
python3 compare_and_extract.py \
  samples.json \
  model_a.jsonl model_b.jsonl model_c.jsonl
```

默认生成：

```text
consensus.jsonl
disagreement_report.jsonl
disagreement_samples.json
```

`consensus.jsonl` 示例：

```jsonl
{"id": 1, "result": 0}
{"id": 5, "result": 1}
```

`disagreement_report.jsonl` 示例：

```jsonl
{"id": 2, "reason": "结果不一致", "results": {"model_a.jsonl": 0, "model_b.jsonl": 1, "model_c.jsonl": 0}, "missing_files": []}
```

自定义字段：

```bash
python3 compare_and_extract.py \
  samples.json \
  a.jsonl b.jsonl c.jsonl \
  --sample-id-key sample_id \
  --result-id-key sample_id \
  --result-key prediction \
  --output-id-key id \
  --output-result-key label
```

嵌套字段也支持点路径：

```bash
--sample-id-key meta.id
--result-key annotation.label
```

默认情况下，某个 ID 在部分结果文件中缺失也会进入分歧结果。忽略缺失 ID：

```bash
python3 compare_and_extract.py samples.json a.jsonl b.jsonl \
  --ignore-missing
```

---

## 2. 终端人工标注

```bash
python3 manual_label.py \
  disagreement_samples.json \
  human_labels.jsonl \
  --image-dir /data/images
```

按键：

```text
← / ↑     上一个样例
→ / ↓     下一个样例
0         无风险
1         有风险
d         删除当前标注
g         跳到第一个未标注样例
[ / ]     切换同一样例中的图片
Home/End  第一条/最后一条
q         保存并退出
```

默认输出：

```jsonl
{"id": 1001, "result": 0}
{"id": 1002, "result": 1}
```

自定义字段名：

```bash
python3 manual_label.py samples.json human.jsonl \
  --id-key sample_id \
  --output-id-key sample_id \
  --output-result-key label
```

从指定 ID 开始：

```bash
python3 manual_label.py samples.json human.jsonl \
  --start-id 12345
```

图片字段支持常见形式：

```json
{"image_id": "abc123"}
{"image_path": "images/a.png"}
{"type": "image_id", "image_id": "abc123"}
```

当 `image_id` 没有扩展名时，会自动尝试：

```text
.png .jpg .jpeg .webp .gif .bmp .tif .tiff
```

---

## 3. 按 ID 替换判定结果

第一个参数是待替换文件，第二个参数是替换来源文件：

```bash
python3 replace_results.py target.jsonl replacement.jsonl
```

默认行为：

- 按相同 ID 匹配；
- 只替换判定字段，不改变 target 中其他字段；
- 原地覆盖 `target.jsonl`；
- 自动创建 `target.jsonl.bak`。

输出到新文件而不覆盖：

```bash
python3 replace_results.py \
  target.jsonl replacement.jsonl \
  -o updated.jsonl
```

自定义字段：

```bash
python3 replace_results.py target.jsonl replacement.jsonl \
  --target-id-key id \
  --replacement-id-key sample_id \
  --target-result-key result \
  --replacement-result-key label
```

将 replacement 中 target 不存在的新 ID 追加到输出：

```bash
python3 replace_results.py target.jsonl replacement.jsonl \
  --append-new
```

---

## 支持的输入结构

### JSON 数组

```json
[
  {"id": 1, "result": 0},
  {"id": 2, "result": 1}
]
```

### JSON 包装对象

```json
{
  "data": [
    {"id": 1, "result": 0}
  ]
}
```

也支持 `samples`、`items`、`records`、`results` 作为列表字段。

### JSONL

```jsonl
{"id": 1, "result": 0}
{"id": 2, "result": 1}
```
