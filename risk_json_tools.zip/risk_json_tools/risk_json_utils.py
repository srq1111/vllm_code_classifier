#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""JSON/JSONL 风险样例处理工具的公共函数。"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Iterable

COMMON_ID_KEYS = ("id", "sample_id", "uid", "index")
COMMON_RESULT_KEYS = (
    "result", "label", "prediction", "pred", "risk",
    "is_risk", "isRisk", "answer", "output"
)


def normalize_json_container(data: Any) -> list[Any]:
    """将常见 JSON 顶层结构统一转换为记录列表。"""
    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        for key in ("data", "samples", "items", "records", "results"):
            value = data.get(key)
            if isinstance(value, list):
                return value

        # 单条样例对象
        if any(key in data for key in COMMON_ID_KEYS):
            return [data]

        # {"1001": {...}, "1002": {...}} 形式
        if data and all(isinstance(v, dict) for v in data.values()):
            records = []
            for map_key, value in data.items():
                row = dict(value)
                if not any(k in row for k in COMMON_ID_KEYS):
                    row["id"] = map_key
                records.append(row)
            return records

    raise ValueError(
        "不支持的 JSON 顶层结构。应为数组、单条对象、"
        '{"data":[...]} 等包装对象，或以 ID 为键的对象。'
    )


def read_json_or_jsonl(path: str | os.PathLike[str]) -> list[Any]:
    """读取 JSON 数组/对象或 JSONL，并返回记录列表。"""
    p = Path(path)
    text = p.read_text(encoding="utf-8-sig")
    stripped = text.lstrip()
    if not stripped:
        return []

    # 优先按完整 JSON 解析；失败后按 JSONL 逐行解析。
    if stripped[0] in "[{":
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            pass
        else:
            return normalize_json_container(data)

    records = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"{p}: 第 {line_no} 行不是合法 JSON：{exc}"
            ) from exc
    return records


def get_by_path(obj: Any, path: str) -> Any:
    """使用点路径读取嵌套字段，例如 meta.label。"""
    current = obj
    for part in path.split("."):
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            raise KeyError(path)
    return current


def set_by_path(obj: dict[str, Any], path: str, value: Any) -> None:
    """使用点路径设置嵌套字段。"""
    parts = path.split(".")
    current = obj
    for part in parts[:-1]:
        child = current.get(part)
        if not isinstance(child, dict):
            child = {}
            current[part] = child
        current = child
    current[parts[-1]] = value


def auto_get(
    record: Any,
    explicit_key: str | None,
    candidates: Iterable[str],
    field_name: str,
) -> tuple[Any, str]:
    """显式字段优先，否则从候选字段中自动识别。"""
    if not isinstance(record, dict):
        raise ValueError(f"记录不是 JSON 对象，无法读取{field_name}")

    if explicit_key:
        try:
            return get_by_path(record, explicit_key), explicit_key
        except KeyError as exc:
            raise KeyError(
                f"找不到{field_name}字段 {explicit_key!r}"
            ) from exc

    for key in candidates:
        if key in record:
            return record[key], key

    raise KeyError(
        f"无法自动识别{field_name}字段。候选字段："
        f"{', '.join(candidates)}；当前字段：{', '.join(map(str, record.keys()))}"
    )


def normalize_id(value: Any) -> str:
    """将不同类型的 ID 转成稳定的匹配键。"""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def canonical_result(value: Any) -> str:
    """规范化结果，令 1、'1'、True 等常见写法可视为一致。"""
    if isinstance(value, str):
        text = value.strip()
        lower = text.lower()
        aliases = {
            "true": "1",
            "false": "0",
            "risk": "1",
            "risky": "1",
            "unsafe": "1",
            "有风险": "1",
            "safe": "0",
            "no_risk": "0",
            "non-risk": "0",
            "无风险": "0",
        }
        if lower in aliases:
            return aliases[lower]
        if text in {"0", "1"}:
            return text
        return text

    if value is True:
        return "1"
    if value is False:
        return "0"
    if isinstance(value, (int, float)) and value in (0, 1):
        return str(int(value))

    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def write_json(path: str | os.PathLike[str], records: list[Any]) -> None:
    Path(path).write_text(
        json.dumps(records, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def write_jsonl(
    path: str | os.PathLike[str],
    records: Iterable[Any],
) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")


def atomic_write_jsonl(
    path: str | os.PathLike[str],
    records: Iterable[Any],
) -> None:
    """原子覆盖 JSONL，避免标注过程中断导致文件损坏。"""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(f".{p.name}.tmp")
    write_jsonl(tmp, records)
    os.replace(tmp, p)
