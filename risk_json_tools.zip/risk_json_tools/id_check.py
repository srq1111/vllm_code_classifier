#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查 JSONL 结果文件中的 ID 是否与 JSON/JSONL 样例文件严格一一对应。

检查项目：
  1. 样例文件是否存在重复 ID
  2. 结果文件是否存在重复 ID
  3. 样例中存在、结果中缺失的 ID
  4. 结果中存在、样例中不存在的多余 ID
  5. 两侧唯一 ID 数量是否一致

默认生成 JSON 报告；还可导出缺失样例和多余结果记录。
"""

from __future__ import annotations

import argparse
from collections import Counter, OrderedDict
from pathlib import Path
from typing import Any

from risk_json_utils import (
    COMMON_ID_KEYS,
    auto_get,
    normalize_id,
    read_json_or_jsonl,
    write_json,
    write_jsonl,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="检查结果 JSONL 与样例 JSON 的 ID 是否严格一一对应。"
    )
    parser.add_argument("samples", help="原始样例 JSON/JSONL 文件")
    parser.add_argument("results", help="待检查结果 JSONL/JSON 文件")
    parser.add_argument(
        "--sample-id-key",
        help="样例 ID 字段，支持 meta.id；默认自动识别",
    )
    parser.add_argument(
        "--result-id-key",
        help="结果 ID 字段，支持 meta.id；默认自动识别",
    )
    parser.add_argument(
        "--report",
        default="id_check_report.json",
        help="检查报告，默认 id_check_report.json",
    )
    parser.add_argument(
        "--missing-samples-output",
        help="可选：导出结果文件中缺失 ID 对应的原始样例 JSON",
    )
    parser.add_argument(
        "--extra-results-output",
        help="可选：导出结果文件中多余 ID 对应的结果记录 JSONL",
    )
    parser.add_argument(
        "--duplicate-samples-output",
        help="可选：导出样例文件中重复 ID 的全部记录 JSON",
    )
    parser.add_argument(
        "--duplicate-results-output",
        help="可选：导出结果文件中重复 ID 的全部记录 JSONL",
    )
    parser.add_argument(
        "--strict-exit-code",
        action="store_true",
        help="发现任何不一致时返回退出码 1，便于脚本/流水线检查",
    )
    return parser.parse_args()


def collect_ids(
    rows: list[Any],
    explicit_key: str | None,
    source_name: str,
) -> tuple[
    list[str],
    dict[str, Any],
    dict[str, list[int]],
]:
    normalized_ids: list[str] = []
    raw_id_map: dict[str, Any] = {}
    positions: dict[str, list[int]] = OrderedDict()

    for index, row in enumerate(rows, start=1):
        try:
            raw_id, _ = auto_get(
                row,
                explicit_key,
                COMMON_ID_KEYS,
                f"{source_name} ID",
            )
        except (KeyError, ValueError) as exc:
            raise ValueError(
                f"{source_name} 第 {index} 条记录无法读取 ID：{exc}"
            ) from exc

        normalized = normalize_id(raw_id)
        normalized_ids.append(normalized)
        raw_id_map.setdefault(normalized, raw_id)
        positions.setdefault(normalized, []).append(index)

    return normalized_ids, raw_id_map, positions


def duplicate_details(
    positions: dict[str, list[int]],
    raw_ids: dict[str, Any],
) -> list[dict[str, Any]]:
    return [
        {
            "id": raw_ids[normalized_id],
            "count": len(row_numbers),
            "record_numbers": row_numbers,
        }
        for normalized_id, row_numbers in positions.items()
        if len(row_numbers) > 1
    ]


def main() -> None:
    args = parse_args()

    samples = read_json_or_jsonl(args.samples)
    results = read_json_or_jsonl(args.results)

    try:
        (
            sample_id_list,
            sample_raw_ids,
            sample_positions,
        ) = collect_ids(
            samples,
            args.sample_id_key,
            f"样例文件 {args.samples}",
        )
        (
            result_id_list,
            result_raw_ids,
            result_positions,
        ) = collect_ids(
            results,
            args.result_id_key,
            f"结果文件 {args.results}",
        )
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc

    sample_set = set(sample_id_list)
    result_set = set(result_id_list)

    missing_ids = [
        normalized_id
        for normalized_id in sample_positions
        if normalized_id not in result_set
    ]
    extra_ids = [
        normalized_id
        for normalized_id in result_positions
        if normalized_id not in sample_set
    ]

    duplicate_sample_ids = [
        normalized_id
        for normalized_id, rows in sample_positions.items()
        if len(rows) > 1
    ]
    duplicate_result_ids = [
        normalized_id
        for normalized_id, rows in result_positions.items()
        if len(rows) > 1
    ]

    is_one_to_one = not (
        missing_ids
        or extra_ids
        or duplicate_sample_ids
        or duplicate_result_ids
        or len(samples) != len(results)
    )

    report = {
        "is_one_to_one": is_one_to_one,
        "samples_file": str(Path(args.samples)),
        "results_file": str(Path(args.results)),
        "summary": {
            "sample_record_count": len(samples),
            "result_record_count": len(results),
            "sample_unique_id_count": len(sample_set),
            "result_unique_id_count": len(result_set),
            "missing_result_id_count": len(missing_ids),
            "extra_result_id_count": len(extra_ids),
            "duplicate_sample_id_count": len(duplicate_sample_ids),
            "duplicate_result_id_count": len(duplicate_result_ids),
        },
        "missing_result_ids": [
            sample_raw_ids[normalized_id]
            for normalized_id in missing_ids
        ],
        "extra_result_ids": [
            result_raw_ids[normalized_id]
            for normalized_id in extra_ids
        ],
        "duplicate_sample_ids": duplicate_details(
            sample_positions,
            sample_raw_ids,
        ),
        "duplicate_result_ids": duplicate_details(
            result_positions,
            result_raw_ids,
        ),
    }

    write_json(args.report, report)

    if args.missing_samples_output:
        missing_set = set(missing_ids)
        missing_samples = [
            row
            for row, normalized_id in zip(samples, sample_id_list)
            if normalized_id in missing_set
        ]
        write_json(args.missing_samples_output, missing_samples)

    if args.extra_results_output:
        extra_set = set(extra_ids)
        extra_results = [
            row
            for row, normalized_id in zip(results, result_id_list)
            if normalized_id in extra_set
        ]
        write_jsonl(args.extra_results_output, extra_results)

    if args.duplicate_samples_output:
        duplicate_set = set(duplicate_sample_ids)
        duplicate_samples = [
            row
            for row, normalized_id in zip(samples, sample_id_list)
            if normalized_id in duplicate_set
        ]
        write_json(args.duplicate_samples_output, duplicate_samples)

    if args.duplicate_results_output:
        duplicate_set = set(duplicate_result_ids)
        duplicate_results = [
            row
            for row, normalized_id in zip(results, result_id_list)
            if normalized_id in duplicate_set
        ]
        write_jsonl(args.duplicate_results_output, duplicate_results)

    print(f"样例记录数：{len(samples)}")
    print(f"结果记录数：{len(results)}")
    print(f"样例唯一 ID：{len(sample_set)}")
    print(f"结果唯一 ID：{len(result_set)}")
    print(f"结果缺失 ID：{len(missing_ids)}")
    print(f"结果多余 ID：{len(extra_ids)}")
    print(f"样例重复 ID：{len(duplicate_sample_ids)}")
    print(f"结果重复 ID：{len(duplicate_result_ids)}")
    print(f"是否严格一一对应：{'是' if is_one_to_one else '否'}")
    print(f"报告文件：{args.report}")

    if missing_ids:
        preview = ", ".join(
            str(sample_raw_ids[item]) for item in missing_ids[:20]
        )
        print(f"缺失 ID 示例：{preview}")

    if extra_ids:
        preview = ", ".join(
            str(result_raw_ids[item]) for item in extra_ids[:20]
        )
        print(f"多余 ID 示例：{preview}")

    if args.strict_exit_code and not is_one_to_one:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
