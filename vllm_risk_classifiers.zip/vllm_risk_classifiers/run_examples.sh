#!/usr/bin/env bash
set -euo pipefail

INPUT=${1:?Usage: $0 /path/to/input.jsonl [base_url] [image_dir]}
BASE_URL=${2:-http://127.0.0.1:8000/v1}
IMAGE_DIR=${3:-$(dirname "$INPUT")}
CONCURRENCY=${CONCURRENCY:-32}

COMMON_ARGS=(--input "$INPUT" --image-dir "$IMAGE_DIR" --base-url "$BASE_URL" --concurrency "$CONCURRENCY")

# 注意：应在对应模型已加载到 vLLM 后逐条执行，不是同时运行六个服务。
python3 run_deepseek_r1_distill_qwen_32b.py "${COMMON_ARGS[@]}"
python3 run_qwen3_5_35b_a3b.py             "${COMMON_ARGS[@]}"
python3 run_qwen3_6_35b_a3b.py             "${COMMON_ARGS[@]}"
python3 run_qwen3_5_27b.py                 "${COMMON_ARGS[@]}"
python3 run_qwen3_6_27b.py                 "${COMMON_ARGS[@]}"
python3 run_gemma3_27b.py                   "${COMMON_ARGS[@]}"
