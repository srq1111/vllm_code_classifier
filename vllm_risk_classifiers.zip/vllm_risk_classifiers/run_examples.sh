#!/usr/bin/env bash
set -euo pipefail

INPUT=${1:?Usage: $0 /path/to/input.json [base_url]}
BASE_URL=${2:-http://127.0.0.1:8000/v1}
CONCURRENCY=${CONCURRENCY:-32}

# 注意：以下命令应在对应模型已加载到 vLLM 后逐条执行。
python3 run_deepseek_r1_distill_qwen_32b.py --input "$INPUT" --base-url "$BASE_URL" --concurrency "$CONCURRENCY"
python3 run_qwen3_5_35b_a3b.py             --input "$INPUT" --base-url "$BASE_URL" --concurrency "$CONCURRENCY"
python3 run_qwen3_6_35b_a3b.py             --input "$INPUT" --base-url "$BASE_URL" --concurrency "$CONCURRENCY"
python3 run_qwen3_5_27b.py                 --input "$INPUT" --base-url "$BASE_URL" --concurrency "$CONCURRENCY"
python3 run_qwen3_6_27b.py                 --input "$INPUT" --base-url "$BASE_URL" --concurrency "$CONCURRENCY"
python3 run_gemma3_27b.py                   --input "$INPUT" --base-url "$BASE_URL" --concurrency "$CONCURRENCY"
