#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
比较 N 个 JSON/JSONL 判定文件：

1. 所有文件中均存在且结果相同的 ID：
   保存到 consensus.jsonl，格式默认为 {"id": ..., "result": ...}

2. 结果不一致或在部分文件中缺失的 ID：
   保存详细报告 disagreement_report.jsonl，
   并从原始样例 JSON/JSONL 中提取到 disagreement_samples.json。
"""

from __future__ import annotations

import argparse
from collections import OrderedDict
from pathlib import Path
from typing import Any

from risk_json_utils import (
    COMMON_ID_KEYS,
    COMMON_RESULT_KEYS,
    auto_get,
    canonical_result,
    normalize_id,
    read_json_or_jsonl,
    write_json,
    write_jsonl,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="比较 N 个判定文件，输出一致结果和不一致原始样例。"
    )
    parser.add_argument(
        "samples",
        help="原始样例 JSON/JSONL 文件",
    )
    parser.add_argument(
        "results",
        nargs="+",
        help="两个或更多待比较的结果 JSON/JSONL 文件",
    )
    parser.add_argument(
        "--consensus",
        default="consensus.jsonl",
        help="一致结果输出文件，默认 consensus.jsonl",
    )
    parser.add_argument(
        "--disagreement-samples",
        default="disagreement_samples.json",
        help="不一致原始样例输出，默认 disagreement_samples.json",
    )
    parser.add_argument(
        "--disagreement-report",
        default="disagreement_report.jsonl",
        help="不一致详情输出，默认 disagreement_report.jsonl",
    )
    parser.add_argument(
        "--sample-id-key",
        help="原始样例的 ID 字段，支持 meta.id",
    )
    parser.add_argument(
        "--result-id-key",
        help="结果文件的 ID 字段，支持 meta.id",
    )
    parser.add_argument(
        "--result-key",
        help="判定字段，支持 meta.label；默认自动识别",
    )
    parser.add_argument(
        "--output-id-key",
        default="id",
        help="一致结果输出中的 ID 字段名，默认 id",
    )
    parser.add_argument(
        "--output-result-key",
        default="result",
        help="一致结果输出中的判定字段名，默认 result",
    )
    parser.add_argument(
        "--ignore-missing",
        action="store_true",
        help="忽略仅在部分文件中出现的 ID，不将其算作不一致",
    )
    return parser.parse_args()


def load_result_file(
    path: str,
    id_key: str | None,
    result_key: str | None,
) -> tuple[OrderedDict[str, tuple[Any, Any]], set[str]]:
    rows = read_json_or_jsonl(path)
    mapping: OrderedDict[str, tuple[Any, Any]] = OrderedDict()
    duplicate_ids: set[str] = set()

    for row_no, row in enumerate(rows, start=1):
        try:
            raw_id, _ = auto_get(row, id_key, COMMON_ID_KEYS, "ID")
            result, _ = auto_get(
                row, result_key, COMMON_RESULT_KEYS, "判定结果"
            )
        except (KeyError, ValueError) as exc:
            raise ValueError(
                f"{path}: 第 {row_no} 条记录读取失败：{exc}"
            ) from exc

        normalized = normalize_id(raw_id)
        if normalized in mapping:
            duplicate_ids.add(normalized)

        # 同一文件中 ID 重复时，采用最后一次写入的结果。
        mapping[normalized] = (raw_id, result)

    return mapping, duplicate_ids


def main() -> None:
    args = parse_args()

    if len(args.results) < 2:
        raise SystemExit("至少需要提供两个结果文件。")

    mappings: list[OrderedDict[str, tuple[Any, Any]]] = []
    for path in args.results:
        mapping, duplicate_ids = load_result_file(
            path,
            args.result_id_key,
            args.result_key,
        )
        mappings.append(mapping)
        if duplicate_ids:
            print(
                f"[提示] {path} 中存在 {len(duplicate_ids)} 个重复 ID，"
                "采用每个 ID 的最后一条结果。"
            )

    # 按各文件中首次出现顺序生成稳定的 ID 顺序。
    ordered_ids: list[str] = []
    seen: set[str] = set()
    for mapping in mappings:
        for normalized_id in mapping:
            if normalized_id not in seen:
                seen.add(normalized_id)
                ordered_ids.append(normalized_id)

    consensus_rows: list[dict[str, Any]] = []
    disagreement_rows: list[dict[str, Any]] = []
    disagreement_ids: set[str] = set()

    for normalized_id in ordered_ids:
        present_values: list[Any] = []
        present_canonical: list[str] = []
        detail: dict[str, Any] = {}
        missing_files: list[str] = []
        raw_id: Any = normalized_id

        for file_path, mapping in zip(args.results, mappings):
            file_name = Path(file_path).name
            if normalized_id in mapping:
                current_raw_id, result = mapping[normalized_id]
                raw_id = current_raw_id
                present_values.append(result)
                present_canonical.append(canonical_result(result))
                detail[file_name] = result
            else:
                detail[file_name] = None
                missing_files.append(file_name)

        appears_in_all = not missing_files
        values_equal = (
            bool(present_canonical)
            and len(set(present_canonical)) == 1
        )

        if appears_in_all and values_equal:
            consensus_rows.append({
                args.output_id_key: raw_id,
                args.output_result_key: present_values[0],
            })
            continue

        if missing_files and args.ignore_missing:
            continue

        disagreement_ids.add(normalized_id)
        if missing_files and not values_equal:
            reason = "结果不一致且部分文件缺失"
        elif missing_files:
            reason = "部分文件缺失"
        else:
            reason = "结果不一致"

        disagreement_rows.append({
            "id": raw_id,
            "reason": reason,
            "results": detail,
            "missing_files": missing_files,
        })

    # 从原始样例文件中提取分歧 ID。
    samples = read_json_or_jsonl(args.samples)
    extracted_samples: list[Any] = []
    found_ids: set[str] = set()

    for row_no, sample in enumerate(samples, start=1):
        try:
            raw_id, _ = auto_get(
                sample,
                args.sample_id_key,
                COMMON_ID_KEYS,
                "样例 ID",
            )
        except (KeyError, ValueError) as exc:
            raise ValueError(
                f"{args.samples}: 第 {row_no} 条样例读取失败：{exc}"
            ) from exc

        normalized_id = normalize_id(raw_id)
        if normalized_id in disagreement_ids:
            extracted_samples.append(sample)
            found_ids.add(normalized_id)

    missing_samples = disagreement_ids - found_ids

    write_jsonl(args.consensus, consensus_rows)
    write_jsonl(args.disagreement_report, disagreement_rows)
    write_json(args.disagreement_samples, extracted_samples)

    print(f"参与比较的结果文件：{len(args.results)}")
    print(f"全部候选 ID：{len(ordered_ids)}")
    print(f"结果一致的 ID：{len(consensus_rows)}")
    print(f"不一致或缺失的 ID：{len(disagreement_rows)}")
    print(f"提取出的原始样例：{len(extracted_samples)}")
    print(f"一致结果：{args.consensus}")
    print(f"分歧详情：{args.disagreement_report}")
    print(f"分歧样例：{args.disagreement_samples}")

    if missing_samples:
        preview = ", ".join(sorted(missing_samples)[:20])
        print(
            f"[警告] 有 {len(missing_samples)} 个分歧 ID "
            f"未在原始样例文件中找到：{preview}"
        )


if __name__ == "__main__":
    main()
