# 本地 vLLM 六模型风险二分类

该目录包含 1 个公共核心和 6 个模型入口脚本。每次只启动一个模型服务，再运行对应脚本；六次运行后得到六个结果 JSON 文件。

## 1. 文件

| 模型 | 入口脚本 | 默认 `--model` | 默认输出 |
|---|---|---|---|
| DeepSeek-R1-Distill-Qwen-32B | `run_deepseek_r1_distill_qwen_32b.py` | `deepseek-r1-distill-qwen-32b` | `result_deepseek_r1_distill_qwen_32b.json` |
| Qwen3.5-35B-A3B | `run_qwen3_5_35b_a3b.py` | `qwen3.5-35b-a3b` | `result_qwen3.5_35b_a3b.json` |
| Qwen3.6-35B-A3B | `run_qwen3_6_35b_a3b.py` | `qwen3.6-35b-a3b` | `result_qwen3.6_35b_a3b.json` |
| Qwen3.5-27B | `run_qwen3_5_27b.py` | `qwen3.5-27b` | `result_qwen3.5_27b.json` |
| Qwen3.6-27B | `run_qwen3_6_27b.py` | `qwen3.6-27b` | `result_qwen3.6_27b.json` |
| Gemma3-27B-it | `run_gemma3_27b.py` | `gemma3-27b-it` | `result_gemma3_27b.json` |

`--model` 必须与 vLLM 启动时的 `--served-model-name` 一致；不一致时在命令行覆盖。

## 2. 安装

```bash
cd vllm_risk_classifiers
python3 -m pip install -r requirements.txt
```

## 3. 输入格式

支持：

1. 标准 JSON 数组；
2. 单个 JSON 对象；
3. JSONL（每行一个 JSON 对象）。

实际文件必须是合法 JSON。示例中的中文弯引号若出现在键名分隔符位置，需先改成英文半角双引号。

图片字段 `image_id` 可以是绝对路径，也可以是相对于输入 JSON 所在目录的路径。也可用 `--image-root /data/images` 指定图片根目录。

## 4. 运行

以 Qwen3.5-27B 为例：

```bash
python3 run_qwen3_5_27b.py \
  --input /data/to_judge.json \
  --base-url http://127.0.0.1:8000/v1 \
  --model qwen3.5-27b \
  --concurrency 32
```

其他模型只需更换入口脚本。`--concurrency` 表示并发上限，默认值为 32。实际并发量自动计算为：

```text
实际并发量 = min(并发上限, 当前待处理记录数)
```

例如：

- 当前有 100 条待处理记录：并发 32 条请求；
- 当前有 20 条待处理记录：并发 20 条请求；
- 队列最后只剩 7 条：立即并发这 7 条，不等待凑满 32 条。

建议先检查数据分类与提示：

```bash
python3 run_qwen3_5_27b.py \
  --input /data/to_judge.json \
  --dry-run
```

先用少量样本联调：

```bash
python3 run_qwen3_5_27b.py \
  --input /data/to_judge.json \
  --limit 100 \
  --concurrency 8
```

## 5. 五类 JSON 的自动识别

- `type=输入侧, is_mt=0` 且无图片：独立文本输入。
- `type=输入侧, is_mt=0` 且有 `image_id/image_url`：独立多模态输入。
- `type=输出侧, is_mt=0`：独立输入+输出。
- `type=输入侧, is_mt=1`：按相同 `mt_id` 分组，再按 `id` 递增拼接到当前问题。
- `type=输出侧, is_mt=1`：审查记录内全部 assistant 回复，任一有风险即为 1。

## 6. 输出

结果是标准 JSON 数组，元素只包含 `id` 和 `result`：

```json
[
  {"id": 20, "result": 0},
  {"id": 21, "result": 1}
]
```

请求失败会写入同名 `.errors.json`，不会把错误信息混进正式结果。DeepSeek 文本模型遇到图片默认跳过，并写入 `.skipped.json`。

DeepSeek 的图片处理策略可选：

```bash
# 默认：跳过图片样本
--unsupported-mm skip

# 遇到图片立即报错
--unsupported-mm error

# 只看图片配套文本，不看图片；一般不建议
--unsupported-mm text-only
```

## 7. vLLM 版本参数

脚本默认针对 vLLM 0.18.x，使用：

```json
{"structured_outputs": {"choice": ["0", "1"]}}
```

这会把最终输出限制为 `0` 或 `1`。若使用 vLLM 0.11 或更早版本，改为：

```bash
--structured-mode legacy
```

若服务端不支持任何结构化输出：

```bash
--structured-mode off
```

Qwen3.5/3.6 请求会自动附带：

```json
{"chat_template_kwargs": {"enable_thinking": false}}
```

用于关闭 reasoning，避免分类任务只返回推理过程。Gemma3 与 DeepSeek 不使用独立 system 角色，全部规则合并到第一条 user 消息。

## 8. 自定义风险口径

默认规则覆盖暴力武器、自伤、色情/未成年人、仇恨极端、违法犯罪/毒品、诈骗、恶意网络攻击、隐私窃取、危险操作和越狱绕过。

若你的标注规范还有政治敏感、广告、伦理、版权等自定义类别，可写入一个文本文件：

```bash
python3 run_qwen3_5_27b.py \
  --input /data/to_judge.json \
  --policy-file /data/risk_policy.txt
```

补充规则会附加到五类精简模板中。
