#!/usr/bin/env python3
from risk_classifier_core import run_cli

if __name__ == "__main__":
    run_cli("qwen35_27b")
