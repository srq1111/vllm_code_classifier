#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
在 Linux/macOS 交互式终端中逐条人工标注风险样例。

按键：
  ← / ↑     上一个样例
  → / ↓     下一个样例
  0         标为无风险
  1         标为有风险
  d         删除当前 ID 已有标注
  g         跳到第一个未标注样例
  [ / ]     切换当前样例中的图片
  Home/End  第一条/最后一条
  r         刷新
  q         保存并退出

每次按 0/1 后立即原子写入 JSONL，因此中途退出不会丢失已完成标注。
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import termios
import textwrap
import tty
from collections import OrderedDict
from pathlib import Path
from typing import Any

from risk_json_utils import (
    COMMON_ID_KEYS,
    COMMON_RESULT_KEYS,
    atomic_write_jsonl,
    auto_get,
    normalize_id,
    read_json_or_jsonl,
)


IMAGE_EXTENSIONS = (
    ".png", ".jpg", ".jpeg", ".webp",
    ".gif", ".bmp", ".tif", ".tiff",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="终端交互式 0/1 风险人工标注工具。"
    )
    parser.add_argument("samples", help="待标注 JSON/JSONL 文件")
    parser.add_argument("output", help="标注结果 JSONL 文件")
    parser.add_argument(
        "--id-key",
        help="样例 ID 字段，支持 meta.id；默认自动识别",
    )
    parser.add_argument(
        "--output-id-key",
        default="id",
        help="输出 ID 字段名，默认 id",
    )
    parser.add_argument(
        "--output-result-key",
        default="result",
        help="输出判定字段名，默认 result",
    )
    parser.add_argument(
        "--image-dir",
        help="图片根目录；image_id 将在该目录中查找",
    )
    parser.add_argument(
        "--chafa",
        default="chafa",
        help="chafa 可执行文件路径，默认 chafa",
    )
    parser.add_argument(
        "--image-height",
        type=int,
        default=18,
        help="图片最大显示高度，默认 18 行",
    )
    parser.add_argument(
        "--start-id",
        help="从指定 ID 开始查看",
    )
    parser.add_argument(
        "--show-all-fields",
        action="store_true",
        help="显示样例全部字段；默认优先显示风险判别相关字段",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="关闭界面标题颜色",
    )
    return parser.parse_args()


def paint(text: str, code: str, no_color: bool) -> str:
    if no_color:
        return text
    return f"\x1b[{code}m{text}\x1b[0m"


def read_key() -> str:
    """在 POSIX 终端 raw mode 中读取单个按键或方向键。"""
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        first = os.read(fd, 1)

        if first == b"\x03":
            return "CTRL_C"
        if first != b"\x1b":
            return first.decode("utf-8", errors="ignore")

        sequence = first
        os.set_blocking(fd, False)
        try:
            for _ in range(8):
                try:
                    part = os.read(fd, 1)
                except BlockingIOError:
                    break
                if not part:
                    break
                sequence += part
                if part.isalpha() or part == b"~":
                    break
        finally:
            os.set_blocking(fd, True)

        return {
            b"\x1b[A": "UP",
            b"\x1b[B": "DOWN",
            b"\x1b[C": "RIGHT",
            b"\x1b[D": "LEFT",
            b"\x1b[H": "HOME",
            b"\x1b[F": "END",
            b"\x1b[1~": "HOME",
            b"\x1b[4~": "END",
        }.get(sequence, "ESC")
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def find_image_values(obj: Any) -> list[str]:
    """递归提取 image_id、image_path 等常见图片字段。"""
    found: list[str] = []

    image_keys = {
        "image_id", "image", "image_path", "img", "img_path",
        "picture", "picture_path", "file_path", "filename",
    }

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            item_type = str(value.get("type", "")).lower()

            if "image" in item_type:
                for key in image_keys:
                    child = value.get(key)
                    if isinstance(child, str) and child.strip():
                        found.append(child.strip())

            for key, child in value.items():
                key_lower = str(key).lower()
                if (
                    isinstance(child, str)
                    and (
                        key_lower in image_keys
                        or key_lower.endswith("_image")
                        or key_lower.endswith("_image_id")
                        or key_lower.endswith("_image_path")
                    )
                ):
                    if child.strip():
                        found.append(child.strip())
                else:
                    visit(child)

        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(obj)
    return list(dict.fromkeys(found))


def resolve_image(
    image_value: str,
    image_dir: str | None,
    samples_file: str,
) -> Path | None:
    """将 image_id 或相对路径解析为本地图片路径。"""
    if image_value.startswith(("http://", "https://", "data:")):
        return None

    raw = Path(image_value).expanduser()
    bases = []

    if image_dir:
        bases.append(Path(image_dir).expanduser().resolve())

    bases.extend([
        Path(samples_file).resolve().parent,
        Path.cwd(),
    ])

    candidates: list[Path] = []

    if raw.is_absolute():
        candidates.append(raw)
    else:
        for base in bases:
            candidates.append(base / raw)

    if not raw.suffix:
        expanded = []
        for candidate in candidates:
            for extension in IMAGE_EXTENSIONS:
                expanded.append(candidate.with_suffix(extension))
        candidates.extend(expanded)

    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()

    return None


def chafa_render(
    executable: str,
    image_path: Path,
    width: int,
    height: int,
) -> str:
    command = [
        executable,
        "--format=symbols",
        f"--size={max(10, width)}x{max(4, height)}",
        "--animate=off",
        str(image_path),
    ]

    try:
        completed = subprocess.run(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
    except FileNotFoundError:
        return (
            "[未找到 chafa。请安装 chafa，"
            "或通过 --chafa 指定可执行文件路径。]"
        )

    if completed.returncode != 0:
        error = completed.stderr.decode(
            "utf-8", errors="replace"
        ).strip()
        return f"[chafa 显示失败：{error or '未知错误'}]"

    return completed.stdout.decode(
        "utf-8", errors="replace"
    ).rstrip("\n")


def sample_text(sample: Any, show_all_fields: bool) -> str:
    if show_all_fields or not isinstance(sample, dict):
        return json.dumps(sample, ensure_ascii=False, indent=2)

    preferred_keys = (
        "id", "type", "is_mt", "messages", "message",
        "content", "text", "prompt", "question", "input",
        "response", "answer",
    )

    selected: OrderedDict[str, Any] = OrderedDict()
    for key in preferred_keys:
        if key in sample:
            selected[key] = sample[key]

    if not selected:
        selected.update(sample)

    return json.dumps(selected, ensure_ascii=False, indent=2)


def wrap_and_clip(text: str, width: int, max_lines: int) -> list[str]:
    lines: list[str] = []

    for raw_line in text.splitlines():
        if not raw_line:
            lines.append("")
            continue

        indent_count = len(raw_line) - len(raw_line.lstrip(" "))
        indent = " " * min(indent_count, max(0, width - 1))
        content = raw_line[indent_count:]

        wrapped = textwrap.wrap(
            content,
            width=max(10, width - len(indent)),
            replace_whitespace=False,
            drop_whitespace=False,
            break_long_words=True,
            break_on_hyphens=False,
        ) or [""]

        lines.extend(indent + part for part in wrapped)

    if len(lines) > max_lines:
        kept = lines[:max(0, max_lines - 1)]
        kept.append(f"...（还有 {len(lines) - len(kept)} 行未显示）")
        return kept

    return lines


def load_existing_labels(
    output_file: str,
    id_key: str,
    result_key: str,
) -> OrderedDict[str, tuple[Any, Any]]:
    labels: OrderedDict[str, tuple[Any, Any]] = OrderedDict()
    path = Path(output_file)

    if not path.exists() or path.stat().st_size == 0:
        return labels

    rows = read_json_or_jsonl(path)

    for row_no, row in enumerate(rows, start=1):
        try:
            raw_id, _ = auto_get(
                row,
                id_key,
                COMMON_ID_KEYS,
                "已有标注 ID",
            )
            result, _ = auto_get(
                row,
                result_key,
                COMMON_RESULT_KEYS,
                "已有判定结果",
            )
        except (KeyError, ValueError) as exc:
            raise ValueError(
                f"{output_file}: 第 {row_no} 条已有标注读取失败：{exc}"
            ) from exc

        labels[normalize_id(raw_id)] = (raw_id, result)

    return labels


def save_labels(
    output_file: str,
    labels: OrderedDict[str, tuple[Any, Any]],
    id_key: str,
    result_key: str,
) -> None:
    rows = [
        {id_key: raw_id, result_key: result}
        for raw_id, result in labels.values()
    ]
    atomic_write_jsonl(output_file, rows)


def first_unlabeled(
    sample_ids: list[tuple[str, Any]],
    labels: dict[str, Any],
) -> int:
    for index, (normalized_id, _) in enumerate(sample_ids):
        if normalized_id not in labels:
            return index
    return 0


def main() -> None:
    args = parse_args()

    if os.name != "posix":
        raise SystemExit(
            "本脚本使用 POSIX 终端按键读取，适用于 Linux/macOS。"
        )
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        raise SystemExit("请在交互式终端中直接运行本脚本。")

    samples = read_json_or_jsonl(args.samples)
    if not samples:
        raise SystemExit("样例文件为空。")

    sample_ids: list[tuple[str, Any]] = []
    id_to_index: dict[str, int] = {}

    for row_no, sample in enumerate(samples, start=1):
        try:
            raw_id, _ = auto_get(
                sample,
                args.id_key,
                COMMON_ID_KEYS,
                "样例 ID",
            )
        except (KeyError, ValueError) as exc:
            raise SystemExit(
                f"第 {row_no} 条样例无法读取 ID：{exc}"
            ) from exc

        normalized_id = normalize_id(raw_id)
        if normalized_id in id_to_index:
            raise SystemExit(f"样例文件中存在重复 ID：{raw_id!r}")

        id_to_index[normalized_id] = row_no - 1
        sample_ids.append((normalized_id, raw_id))

    labels = load_existing_labels(
        args.output,
        args.output_id_key,
        args.output_result_key,
    )

    if args.start_id is not None:
        start_key = normalize_id(args.start_id)
        if start_key not in id_to_index:
            raise SystemExit(f"找不到 --start-id {args.start_id!r}")
        current_index = id_to_index[start_key]
    else:
        current_index = first_unlabeled(sample_ids, labels)

    image_index_by_id: dict[str, int] = {}
    notice = ""
    quit_requested = False

    # 使用备用屏幕，退出时恢复原终端内容。
    sys.stdout.write("\x1b[?1049h\x1b[?25l")
    sys.stdout.flush()

    try:
        while not quit_requested:
            terminal = shutil.get_terminal_size(fallback=(120, 40))
            width = max(50, terminal.columns)
            height = max(18, terminal.lines)

            sample = samples[current_index]
            normalized_id, raw_id = sample_ids[current_index]
            current_result = labels.get(
                normalized_id, (None, None)
            )[1]
            labeled_count = sum(
                1 for sid, _ in sample_ids if sid in labels
            )

            image_values = find_image_values(sample)
            images = [
                (
                    value,
                    resolve_image(value, args.image_dir, args.samples),
                )
                for value in image_values
            ]

            image_index = image_index_by_id.get(normalized_id, 0)
            if images:
                image_index %= len(images)
                image_index_by_id[normalized_id] = image_index

            sys.stdout.write("\x1b[2J\x1b[H")

            status = (
                f"样例 {current_index + 1}/{len(samples)}  "
                f"ID={raw_id}  "
                f"判定={current_result if current_result is not None else '未标注'}  "
                f"进度={labeled_count}/{len(samples)}"
            )
            print(paint(status, "1;36", args.no_color))
            print(
                paint(
                    "方向键切换 | 0 无风险 | 1 有风险 | "
                    "d 删除 | g 未标注 | [ ] 切图 | q 退出",
                    "2",
                    args.no_color,
                )
            )
            print(
                paint(notice, "1;33", args.no_color)
                if notice else ""
            )

            used_rows = 3

            if images:
                raw_image, local_path = images[image_index]
                print(
                    paint(
                        f"图片 {image_index + 1}/{len(images)}："
                        f"{local_path if local_path else raw_image}",
                        "1;35",
                        args.no_color,
                    )
                )
                used_rows += 1

                if local_path:
                    image_height = min(
                        args.image_height,
                        max(4, height // 2),
                    )
                    rendered = chafa_render(
                        args.chafa,
                        local_path,
                        min(width, 110),
                        image_height,
                    )
                    print(rendered)
                    used_rows += rendered.count("\n") + 1
                else:
                    print(
                        "[未找到本地图片。请检查 image_id，"
                        "或使用 --image-dir 指定图片目录。]"
                    )
                    used_rows += 1

            print(paint("─" * min(width, 120), "2", args.no_color))
            used_rows += 1

            body = sample_text(sample, args.show_all_fields)
            available_lines = max(3, height - used_rows - 1)
            for line in wrap_and_clip(body, width, available_lines):
                print(line)

            sys.stdout.flush()
            notice = ""
            key = read_key()

            if key in ("q", "Q", "CTRL_C"):
                quit_requested = True

            elif key in ("LEFT", "UP"):
                current_index = (current_index - 1) % len(samples)

            elif key in ("RIGHT", "DOWN"):
                current_index = (current_index + 1) % len(samples)

            elif key in ("0", "1"):
                result = int(key)
                labels[normalized_id] = (raw_id, result)
                save_labels(
                    args.output,
                    labels,
                    args.output_id_key,
                    args.output_result_key,
                )
                notice = (
                    f"已写入：ID={raw_id}, "
                    f"{args.output_result_key}={result}"
                )
                current_index = (current_index + 1) % len(samples)

            elif key in ("d", "D"):
                if normalized_id in labels:
                    del labels[normalized_id]
                    save_labels(
                        args.output,
                        labels,
                        args.output_id_key,
                        args.output_result_key,
                    )
                    notice = f"已删除 ID={raw_id} 的标注"
                else:
                    notice = "当前样例尚未标注"

            elif key in ("g", "G"):
                current_index = first_unlabeled(
                    sample_ids,
                    labels,
                )
                notice = "已跳到第一个未标注样例"

            elif key == "[" and images:
                image_index_by_id[normalized_id] = (
                    image_index - 1
                ) % len(images)

            elif key == "]" and images:
                image_index_by_id[normalized_id] = (
                    image_index + 1
                ) % len(images)

            elif key == "HOME":
                current_index = 0

            elif key == "END":
                current_index = len(samples) - 1

            elif key in ("r", "R"):
                notice = "已刷新"

    finally:
        sys.stdout.write("\x1b[?25h\x1b[?1049l")
        sys.stdout.flush()

    print(
        f"已退出。当前已标注 {len(labels)}/{len(samples)} 条；"
        f"结果文件：{args.output}"
    )


if __name__ == "__main__":
    main()
